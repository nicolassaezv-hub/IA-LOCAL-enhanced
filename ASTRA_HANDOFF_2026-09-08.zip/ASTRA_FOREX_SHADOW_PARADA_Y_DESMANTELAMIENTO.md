# ASTRA Forex Shadow — Guía de parada, pausa, recuperación y desmantelamiento

**Fecha de referencia:** 2026-09-07

## Estado conocido
- Oracle: `astra-shadow.timer` activo y habilitado.
- Forex: `EURUSD` y `USDJPY`.
- Señal: `H1`; contexto: `H4` y `D1`.
- Trading real: **OFF**.
- Retraining: **congelado**.
- Supervisor Windows: `ASTRA MT5 Bridge Supervisor`.
- Bridge: `C:\ASTRA\mt5-bridge`.
- Token Windows: `C:\ProgramData\ASTRA\mt5-bridge.token`.
- Token Oracle: `/etc/astra/mt5_bridge.token`.
- Backup conocido: `/var/backups/astra/restricted-shadow-20260908T010406Z`.
- Azure VM: `astra-mt5-worker`.
- Resource Group: `astra-forex-worker-rg`.
- Tailscale Windows: `100.101.198.61`.
- Tailscale Oracle: `100.87.181.46`.

> Nunca pegues ni compartas el contenido de tokens o claves.

---

# 1. Parar Shadow Forex sin borrar nada

En Oracle:

```bash
sudo systemctl disable --now astra-shadow.timer
```

Verifica:

```bash
systemctl is-enabled astra-shadow.timer
systemctl is-active astra-shadow.timer
systemctl list-timers --all | grep -iE 'astra|forex|shadow'
```

Esperado:

```text
disabled
inactive
```

---

# 2. Reactivar Shadow Forex

Primero comprueba que Windows/MT5/bridge estén sanos.

Luego en Oracle:

```bash
sudo systemctl enable --now astra-shadow.timer
```

Verifica:

```bash
systemctl is-enabled astra-shadow.timer
systemctl is-active astra-shadow.timer
systemctl status astra-shadow.timer --no-pager
```

Logs recientes:

```bash
journalctl -u astra-shadow.service -n 100 --no-pager
```

Si ese service no existe con ese nombre, inspecciona:

```bash
systemctl cat astra-shadow.timer
```

y usa el `Unit=` real que aparezca.

---

# 3. Detener supervisor/bridge en Windows

Ejecutar dentro de la VM Windows Azure, PowerShell como Administrador:

```powershell
Disable-ScheduledTask -TaskName 'ASTRA MT5 Bridge Supervisor'
Stop-ScheduledTask -TaskName 'ASTRA MT5 Bridge Supervisor'
```

Verifica:

```powershell
Get-ScheduledTask -TaskName 'ASTRA MT5 Bridge Supervisor' |
    Format-List TaskName,State
```

Si quieres terminar además el bridge actual:

```powershell
$bridge = Get-CimInstance Win32_Process | Where-Object {
    $_.Name -match '^python(\.exe)?$' -and
    $_.CommandLine -match 'uvicorn' -and
    $_.CommandLine -match 'bridge:app' -and
    $_.CommandLine -match 'C:\\ASTRA\\mt5-bridge'
}

$bridge | Select-Object ProcessId,Name,CommandLine
```

Revisa la salida. Si corresponde únicamente al bridge ASTRA:

```powershell
$bridge | ForEach-Object {
    Stop-Process -Id $_.ProcessId -Force
}
```

> Deshabilita primero el supervisor o volverá a levantar el bridge.

---

# 4. Reactivar supervisor/bridge Windows

```powershell
Enable-ScheduledTask -TaskName 'ASTRA MT5 Bridge Supervisor'
Start-ScheduledTask -TaskName 'ASTRA MT5 Bridge Supervisor'
Start-Sleep -Seconds 5
```

Verifica:

```powershell
Get-ScheduledTask -TaskName 'ASTRA MT5 Bridge Supervisor' |
    Format-List TaskName,State

Get-ScheduledTaskInfo -TaskName 'ASTRA MT5 Bridge Supervisor' |
    Format-List LastRunTime,LastTaskResult
```

`267009` = `0x41301` = tarea ejecutándose.

Self-healing:

```powershell
& 'C:\ASTRA\mt5-bridge\verify-self-healing.ps1' -BindAddress '100.101.198.61'
```

---

# 5. Cortar el gasto de compute Azure sin borrar la VM

La VM debe quedar en **Stopped (Deallocated)**.

Azure CLI:

```bash
az vm deallocate   --resource-group astra-forex-worker-rg   --name astra-mt5-worker
```

Verifica:

```bash
az vm get-instance-view   --resource-group astra-forex-worker-rg   --name astra-mt5-worker   --query "instanceView.statuses[].displayStatus"   -o table
```

Debe aparecer:

```text
VM deallocated
```

También puedes hacerlo desde Azure Portal:
`Virtual Machines` → `astra-mt5-worker` → `Stop` → esperar `Stopped (deallocated)`.

## Costos que pueden seguir existiendo
- Managed OS Disk.
- Public IP Standard.
- Snapshots/backups si existen.
- Cualquier servicio adicional de pago.

---

# 6. Volver a encender Azure

```bash
az vm start   --resource-group astra-forex-worker-rg   --name astra-mt5-worker
```

Después, dentro de Windows:

```powershell
Get-Service Tailscale

Get-ScheduledTask -TaskName 'ASTRA MT5 Bridge Supervisor' |
    Format-List TaskName,State
```

Confirma además que MT5 esté conectado a:

```text
IFCMarkets-Demo
```

No reactives el timer Oracle hasta confirmar Tailscale + MT5 + bridge.

---

# 7. Si vas a abandonar ASTRA semanas o meses

La opción reversible recomendada:

## Oracle

```bash
sudo systemctl disable --now astra-shadow.timer
```

## Windows

```powershell
Disable-ScheduledTask -TaskName 'ASTRA MT5 Bridge Supervisor'
Stop-ScheduledTask -TaskName 'ASTRA MT5 Bridge Supervisor'
```

## Azure

```bash
az vm deallocate   --resource-group astra-forex-worker-rg   --name astra-mt5-worker
```

Así no se generan nuevas señales, se detiene el compute Azure y no se borra nada.

---

# 8. Backup antes de cualquier desmantelamiento

En Oracle:

```bash
STAMP="$(date -u +%Y%m%dT%H%M%SZ)"
sudo install -d -m 700 /var/backups/astra
sudo tar --xattrs --acls -czf   "/var/backups/astra/astra-pre-shutdown-${STAMP}.tar.gz"   /opt/astra /etc/astra
sudo chmod 600 "/var/backups/astra/astra-pre-shutdown-${STAMP}.tar.gz"
sudo ls -lh "/var/backups/astra/astra-pre-shutdown-${STAMP}.tar.gz"
```

Verifica también el rollback previo:

```bash
sudo ls -ld /var/backups/astra/restricted-shadow-20260908T010406Z
```

> El backup incluye `/etc/astra`; puede contener secretos. No lo compartas ni lo subas sin cifrar.

---

# 9. Desmantelamiento reversible

Haz esto si quieres dejar ASTRA Forex inactivo pero recuperable:

1. Deshabilita `astra-shadow.timer`.
2. Deshabilita el supervisor Windows.
3. Haz backup Oracle.
4. Deallocate Azure.
5. Conserva VM, disco, IP, `/opt/astra`, `/etc/astra`, `/var/backups/astra`, modelos, DB y tokens.

Esto equivale a hibernar el proyecto.

---

# 10. Desmantelamiento definitivo

> ⚠️ DESTRUCTIVO. No usar si solo quieres ahorrar temporalmente.

Primero:

```bash
sudo systemctl disable --now astra-shadow.timer
```

Haz el backup de la sección 8.

Deallocate:

```bash
az vm deallocate   --resource-group astra-forex-worker-rg   --name astra-mt5-worker
```

Inspecciona recursos:

```bash
az vm show   --resource-group astra-forex-worker-rg   --name astra-mt5-worker   -o json

az resource list   --resource-group astra-forex-worker-rg   -o table
```

Solo si confirmaste que no necesitas volver a iniciar la VM:

```bash
az vm delete   --resource-group astra-forex-worker-rg   --name astra-mt5-worker   --yes
```

Luego vuelve a listar:

```bash
az resource list   --resource-group astra-forex-worker-rg   -o table
```

Borrar la VM no garantiza borrar automáticamente OS Disk, NIC o Public IP.

Si el Resource Group contiene únicamente este worker y quieres eliminar absolutamente todo:

```bash
az group delete   --name astra-forex-worker-rg   --yes   --no-wait
```

> ⚠️ Esto elimina todos los recursos dentro de `astra-forex-worker-rg`.

---

# 11. No borres Oracle para ahorrar Azure

Oracle contiene el núcleo de ASTRA, datasets, modelos, shadow results, outcomes, logs y backups.

No ejecutes:

```text
rm -rf /opt/astra
```

ni borres `/etc/astra` o `/var/backups/astra` como parte de una reducción de costos Azure.

---

# 12. Checklist de seguridad antes de reactivar

```text
[ ] EURUSD y USDJPY únicamente.
[ ] H1 señal principal.
[ ] H4/D1 solo contexto.
[ ] Trading real OFF.
[ ] Retraining congelado.
[ ] Sin order_send.
[ ] Sin endpoints de trading.
[ ] Timers históricos fuera del flujo.
[ ] scheduler_service.py fuera del Shadow actual.
[ ] IFCMarkets-Demo conectado.
[ ] RemoteMT5Provider sano.
[ ] Supervisor Windows Running.
[ ] astra-shadow.timer se activa al final.
```

Si alguna condición falla, mantén `astra-shadow.timer` deshabilitado.

---

# 13. Diagnóstico rápido

## Oracle

```bash
systemctl status astra-shadow.timer --no-pager
systemctl list-timers --all | grep -iE 'astra|forex|shadow'
journalctl -u astra-shadow.service -n 100 --no-pager
```

## Windows

```powershell
Get-ScheduledTask -TaskName 'ASTRA MT5 Bridge Supervisor' |
    Format-List TaskName,State

Get-ScheduledTaskInfo -TaskName 'ASTRA MT5 Bridge Supervisor' |
    Format-List LastRunTime,LastTaskResult

& 'C:\ASTRA\mt5-bridge\verify-self-healing.ps1' -BindAddress '100.101.198.61'
```

## Azure

```bash
az vm get-instance-view   --resource-group astra-forex-worker-rg   --name astra-mt5-worker   --query "instanceView.statuses[].displayStatus"   -o table
```

---

# 14. Detener todo en menos de un minuto

En Oracle:

```bash
sudo systemctl disable --now astra-shadow.timer
```

Luego deallocate Azure:

```bash
az vm deallocate   --resource-group astra-forex-worker-rg   --name astra-mt5-worker
```

Esto detiene nuevas señales y corta el compute Azure sin destruir datos.

---

# 15. Volver después de dos meses

```text
1. Revisar saldo/costos Azure.
2. Encender astra-mt5-worker.
3. Entrar por RDP.
4. Confirmar Tailscale.
5. Confirmar IFCMarkets-Demo.
6. Confirmar ASTRA MT5 Bridge Supervisor = Running.
7. Ejecutar verify-self-healing.ps1.
8. Confirmar Oracle obtiene EURUSD/USDJPY.
9. Confirmar Trading = OFF.
10. Confirmar Retraining = FROZEN.
11. Activar astra-shadow.timer.
12. Revisar el primer ciclo en journal.
```

---

# 16. Regla de oro

Si dudas entre borrar o detener:

```text
DISABLE + DEALLOCATE
```

Es reversible.

Solo elimina definitivamente cuando tengas:

```text
backup verificado
+ datos preservados
+ decisión consciente de no volver
```

---

## Checkpoint de referencia

```text
ASTRA FOREX SHADOW — ACTIVE & VERIFIED
EURUSD/USDJPY
H1 + H4/D1
Trading OFF
Retraining FROZEN
Self-healing Windows PASS
Oracle timer ACTIVE
```
