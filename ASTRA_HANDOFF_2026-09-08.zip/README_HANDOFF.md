# ASTRA HANDOFF PACKAGE

Archivos:
- `ASTRA_MASTER_CONTEXT.md`: memoria portátil canónica.
- `CODEX_HANDOFF_FINAL.md`: tarea exacta para Codex.
- `ASTRA_FOREX_SHADOW_PARADA_Y_DESMANTELAMIENTO.md`: runbook operativo.

## Para otra IA

Adjuntar los archivos y decir:

> Lee `ASTRA_MASTER_CONTEXT.md` completamente antes de proponer cambios. Es el snapshot canónico de ASTRA. Usa luego el repositorio como fuente primaria de código y verifica cualquier estado live antes de modificar infraestructura. No reveles secretos ni amplíes Forex fuera de las restricciones establecidas.

## Para Codex

Abrir Codex/Work sobre el repositorio y adjuntar o pegar `CODEX_HANDOFF_FINAL.md`.

Codex debe entregar `ASTRA_HANDOFF_FINAL_RESULTADO.md`.
