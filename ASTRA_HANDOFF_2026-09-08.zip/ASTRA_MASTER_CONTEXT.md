# ASTRA — MASTER CONTEXT

**Snapshot canónico:** 2026-09-08  
**Propósito:** memoria portátil del proyecto ASTRA para continuar con ChatGPT, Codex, Claude, Gemini u otra IA.  
**Regla:** si una IA asume algo que contradice este documento, prevalece este documento hasta que el usuario confirme un cambio.

---

## 1. Qué es ASTRA

ASTRA es un asistente IA modular/local con múltiples herramientas y ramas funcionales. No es solo un chatbot: combina memoria, archivos, herramientas, Workspace, Prediction Lab, Evolution Engine y una rama Forex desplegada en infraestructura real.

Repositorio principal: `nicolassaezv-hub/IA-LOCAL-enhanced`

Módulos/áreas conocidas: `main.py`, `tool_registry.py`, `astra_agent.py`, memoria/persistencia, `conversation_context.py`, `analytics_memory.py`, `forex_analytics.py`, archivos, AI models, web/audio/video/visualization/security/utils, Workspace, Prediction Lab, Evolution Engine y Forex.

---

## 2. Reglas de colaboración

- Responder principalmente en español.
- Preferir checkpoints PASS / FAIL.
- Dar comandos copy/paste cuando corresponda.
- Distinguir siempre entre PC personal, Oracle Cloud y VM Windows Azure.
- Cambios mínimos, reversibles y verificables.
- Antes de cambios destructivos: backup + rollback.
- No inventar estado de repositorio, VMs ni servicios.
- No revelar secretos.
- No reabrir investigación ML en Forex durante shadow salvo autorización explícita.

---

## 3. Hard constraints de Forex

Alcance congelado para validación Shadow:
- EURUSD
- USDJPY
- H1 = señal principal
- H4/D1 = contexto
- BUY / SELL / HOLD

Prohibido salvo autorización futura explícita:
- capital real
- `order_send`
- endpoints de trading real
- nuevos pares
- nuevos targets
- nuevos modelos
- Optuna
- retraining automático
- MT5 en Oracle ARM
- Wine/emulación ARM
- PC personal como worker permanente
- bridge 8767 público
- timers Forex históricos paralelos
- `scheduler_service.py` como flujo Shadow actual

---

## 4. Infraestructura actual

### Oracle Cloud
- núcleo central ASTRA
- Ubuntu 24.04 ARM
- 2 CPU
- ~11 GiB RAM
- runtime: `/opt/astra`
- source: `/home/ubuntu/astra-source`
- API local: `127.0.0.1:8000`
- env: `/etc/astra/astra.env`
- permisos esperados env: `root:astra 640`
- Shadow Forex corre desde Oracle

### Azure Windows worker
- VM: `astra-mt5-worker`
- Resource Group: `astra-forex-worker-rg`
- South Africa North / Zone 1
- Windows Server 2022 Datacenter Azure Edition GUI
- x64
- `Standard B2als_v2`
- 2 vCPU
- 4 GiB RAM
- Standard SSD LRS
- OS disk observado: E10 / 128 GiB
- Trusted Launch / Secure Boot / vTPM
- accelerated networking
- RDP restringido
- bridge no público

Rol Azure: MT5 + IFCMarkets-Demo + Python + FastAPI/Uvicorn bridge + Tailscale. No ejecutar ASTRA completo ni ML pesado ahí.

---

## 5. Tailscale y bridge

Tailscale:
- Windows: `100.101.198.61`
- Oracle: `100.87.181.46`

Bridge:
- ruta Windows: `C:\ASTRA\mt5-bridge`
- escucha: `100.101.198.61:8767`
- token Windows: `C:\ProgramData\ASTRA\mt5-bridge.token`
- token Oracle: `/etc/astra/mt5_bridge.token`
- no documentar valores de tokens

Endpoints:
- `/health`
- `/v1/status` autenticado
- `/v1/rates` autenticado

Allowlist:
- EURUSD
- USDJPY

Timeframes:
- H1
- H4
- D1

Restricciones:
- servidor exacto `IFCMarkets-Demo`
- demo trade mode
- no POST trading
- no `order_send`
- fail closed

Timeouts reportados:
- Oracle connect 3 s
- read 10 s
- total 15 s
- lock MT5 8 s

---

## 6. MT5 / datos

Proveedor: MetaTrader 5 / `IFCMarkets-Demo`.

Contrato de datos:
- clock profile Europe/Berlin
- normalización UTC
- excluir vela incompleta
- sanitizar/validar OHLC
- devolver exactamente N barras

Qualification lograda:
- EURUSD/USDJPY visibles
- H1/H4/D1
- 2010 barras en probe
- 0 duplicados
- orden cronológico

RemoteMT5Provider luego validó 2000 barras válidas para los 6 streams:
- EURUSD H1/H4/D1
- USDJPY H1/H4/D1

---

## 7. Supervisor Windows / self-healing

Task Scheduler: `ASTRA MT5 Bridge Supervisor`

Propiedades reportadas:
- tarea oculta bajo `astraadmin`
- una sola instancia
- health autenticada cada 30 s
- restart tras 3 fallos
- termina solo PID validado del bridge
- QuickEdit desactivado
- token existente preservado

Self-healing probado: PID `4816 -> 1420`.

`267009` / `0x41301` = tarea actualmente ejecutándose.

Paquete final reportado: `mt5-bridge-supervisor-v1.1.zip`  
SHA-256: `5a54f403f70051b4d694a624187ff8e28436143e989669fd214e3dc5c6e2ff54`

---

## 8. RemoteMT5Provider

Estado: **QUALIFIED**.

Integrado local + Oracle.

Resultados reportados a lo largo del cierre:
- 1215 tests PASS en suite completa previa
- 286 tests PASS en Oracle ARM
- 2000 barras válidas en los seis streams
- posteriormente 1272 passed, 10 skipped
- 23 subtests específicos PASS

Antes de asumir que todo está en `main`, revisar Git: el deployment live podía estar por delante del remoto público.

---

## 9. Shadow Forex automático

Checkpoint oficial:

`ASTRA FOREX SHADOW — ACTIVE & VERIFIED`

Estado reportado por Codex:
- `astra-shadow.timer`: enabled + active
- primera ejecución automática: success, exit 0
- EURUSD + USDJPY
- H1 señal
- H4/D1 contexto
- trading real OFF
- retraining FROZEN
- timers históricos fuera del flujo
- `scheduler_service.py` fuera del flujo
- supervisor Windows self-healing validado
- Oracle revalidó status y datos después de recovery
- dos primeras señales persistidas: HOLD + HOLD
- sin duplicados
- outcomes probados en E2E aislado
- sin outcome productivo en ese checkpoint porque ambas señales fueron HOLD

Rollback conocido:
`/var/backups/astra/restricted-shadow-20260908T010406Z`

---

## 10. Qué falta demostrar

No falta demostrar que el sistema corre; eso ya pasó.

Falta demostrar valor predictivo real out-of-sample.

Objetivo:
- dejar correr 1–3 meses
- registrar todas las señales
- mínimo deseado: 100 BUY/SELL evaluadas
- HOLD se registra, pero no cuenta como operación BUY/SELL

Métricas deseadas:
- total predictions
- BUY / SELL / HOLD
- accuracy direccional
- net pips
- spread/costos
- Profit Factor
- expectancy
- drawdown
- max consecutive losses
- reliability calibration
- EURUSD separado
- USDJPY separado
- BUY separado
- SELL separado

No usar `win_rate > 50%` como criterio aislado de éxito.

---

## 11. Persistencia Shadow

La IA que continúe debe verificar en código y live dónde se almacenan realmente señales y outcomes, no asumirlo.

Idealmente auditar:
- prediction_id
- pair
- model version/hash si existe
- decision time UTC
- timestamps H1/H4/D1 fuente
- signal
- reliability
- MTF coherence
- regime
- precios/provenance si existen
- spread/costos si existen
- outcome
- deduplicación
- integridad tras reinicios

No contaminar resultados productivos con fixtures sintéticos.

---

## 12. Costos y Azure

Costo observado por el usuario: ~USD 1.5/día con VM + storage + red.

Objetivo futuro: reducir gasto.

Ideas a investigar, no ejecutar a ciegas:
1. Deallocate Azure cuando Forex esté cerrado.
2. Rehacer worker con disco menor E4/E6 si cabe Windows+MT5.
3. Mantener Oracle como control plane/storage principal.
4. No mover Windows a Oracle ARM.
5. Evaluar Contabo/InterServer solo si económicamente conviene frente a créditos Azure.

Regla de ahorro temporal:
`DISABLE + DEALLOCATE`

---

## 13. Fin de créditos Azure

Cuando los créditos estén cerca de expirar:
1. `sudo systemctl disable --now astra-shadow.timer`
2. confirmar disabled/inactive
3. backup Oracle
4. deallocate `astra-mt5-worker`
5. confirmar `Stopped (Deallocated)`
6. exportar/snapshot resultados Shadow
7. analizar resultados live
8. comparar con backtesting
9. decidir si continuar/corregir/prolongar/descartar

Analizar como mínimo:
- total señales
- HOLD / BUY / SELL
- evaluadas/pending
- net pips
- PF
- expectancy
- drawdown
- reliability calibration
- gaps/fallos operativos
- EURUSD vs USDJPY
- BUY vs SELL
- live OOS vs backtest

Nunca pasar a real trading automáticamente.

---

## 14. Manual operativo existente

Conservar junto a este archivo:
`ASTRA_FOREX_SHADOW_PARADA_Y_DESMANTELAMIENTO.md`

Incluye pause/resume, supervisor, deallocate, backup, teardown reversible/definitivo y recovery después de meses.

---

## 15. Git / release

Antes de declarar versión canónica:
- revisar `git status`
- branch
- HEAD local
- HEAD Oracle
- HEAD remoto
- no reset/clean destructivo
- no blind pull
- no sobrescribir cambios live

Todo cambio final de RemoteMT5Provider, Shadow runner y supervisor debe quedar versionado, respaldado y reproducible.

---

## 16. MANUAL y requirements

El repo contiene referencias inconsistentes a `MANUAL.md` y `MANUAL (WIP).md`.

La IA/Codex debe:
- descubrir cuál es el manual canónico actual
- no crear duplicado por adivinar el nombre
- actualizarlo si hace falta con la arquitectura y operación Shadow actuales

Revisar `requirements.txt` y modificarlo solo si las implementaciones finales introdujeron dependencias reales del runtime instalable. No reflejar accidentalmente paquetes de una VM que no correspondan al repo.

---

## 17. Implementaciones futuras

Existe `Implementaciones futuras.md` con ideas de estética, concurrencia, personalización, Kernel Lab, Prediction Lab, Evolution Engine, Auto/Manual Forex y límites de RAM.

Revisión previa global reportada:
- 3 PASS
- 6 PASS CON CONDICIONES
- 1 POSTERGAR
- 1 RECHAZAR

No implementar las 11 de golpe. Prioridad actual: estabilidad + observación Shadow.

---

## 18. Secrets

Nunca incluir valores de:
- GROQ_API_KEY
- Azure credentials
- Oracle SSH private keys
- MT5 password
- Tailscale auth keys
- bridge token
- `.env` completo

Documentar rutas/variables, no valores.

---

## 19. Checkpoint final

```text
ASTRA FOREX SHADOW — ACTIVE & VERIFIED

Oracle core                PASS
Azure Windows worker       PASS
Tailscale                  PASS
MT5 IFCMarkets-Demo        PASS
RemoteMT5Provider          PASS
Bridge auth                PASS
Bridge self-healing        PASS
EURUSD                     ACTIVE
USDJPY                     ACTIVE
H1 signal                  ACTIVE
H4/D1 context              ACTIVE
Shadow timer               ACTIVE
Persistence                PASS (requiere auditoría continua)
Trading                    OFF
Retraining                 FROZEN
Real orders                DISABLED
Live prediction quality    NOT YET PROVEN
100 BUY/SELL               PENDING
1–3 month observation      IN PROGRESS
```
