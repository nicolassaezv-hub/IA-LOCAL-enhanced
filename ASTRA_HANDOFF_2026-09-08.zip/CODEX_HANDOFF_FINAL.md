# CODEX FINAL HANDOFF — ASTRA

## Objetivo

Cerrar y dejar reproducible el estado actual de ASTRA antes de que el usuario pierda temporalmente acceso a ChatGPT Plus.

Lee primero:
1. `ASTRA_MASTER_CONTEXT.md`
2. `ASTRA_FOREX_SHADOW_PARADA_Y_DESMANTELAMIENTO.md`
3. repositorio completo
4. estado live de Oracle y Windows antes de modificar nada

No confíes en nombres históricos si el sistema live demuestra otra cosa.

---

## A. Memoria portátil canónica

Añadir al repositorio una copia segura y sin secretos de `ASTRA_MASTER_CONTEXT.md`, idealmente bajo `docs/` salvo que exista ubicación documental canónica mejor.

Debe permitir a otra IA continuar ASTRA sin acceso a conversaciones anteriores.

NO incluir secretos.

---

## B. Versionar todo lo live

Auditar:
- working tree local
- branch
- HEAD
- remote main
- Oracle deployed code
- cambios de RemoteMT5Provider
- restricted Shadow runner
- systemd units/timer
- outcome persistence
- supervisor Windows
- tests

No reset/clean destructivo.

Si hay código live no committed:
- capturarlo
- comparar
- testear
- versionarlo de forma segura

No subir tokens, `.env`, credenciales ni secretos.

---

## C. Actualizar manual y requirements.txt

### Manual

El repo contiene referencias tanto a `MANUAL.md` como a `MANUAL (WIP).md`.

Primero determinar cuál es el manual canónico real.

NO crear un duplicado por adivinar el nombre.

Actualizar el manual canónico si hace falta con:
- Oracle + Azure actual
- Windows MT5 worker
- Tailscale
- RemoteMT5Provider
- authenticated bridge
- supervisor/self-healing
- EURUSD/USDJPY
- H1 señal + H4/D1 contexto
- Shadow automatic
- `astra-shadow.timer`
- trading OFF
- retraining frozen
- start / stop / recovery
- deallocate Azure
- fin de créditos
- análisis posterior Shadow vs backtest

### requirements.txt

Auditar `requirements.txt`.

Modificar SOLO si la implementación final introdujo dependencias que realmente forman parte del runtime instalable/reproducible.

No añadir paquetes por reflejar accidentalmente el entorno de una VM.

Después ejecutar los tests apropiados.

---

## D. Verificar almacenamiento de resultados Shadow

Auditar el flujo real de persistencia y demostrar con evidencia:
- dónde se guarda cada señal
- schema/tablas/archivos
- timestamps
- pair
- signal
- reliability
- MTF/context
- model/version si existe
- precios/provenance si existen
- outcome
- deduplicación
- integridad tras reinicios

Confirmar:
- los dos HOLD iniciales siguen persistidos si corresponde
- no hay duplicados
- ejecuciones posteriores se almacenan
- BUY/SELL futuros pueden pasar a evaluated outcome
- HOLD no se cuenta como win/loss
- fallo temporal del bridge no crea predicción corrupta

Tests sintéticos pueden usarse solo como fixtures aislados; NO contaminar resultados Shadow productivos.

---

## E. Crear manual de fin de créditos y análisis

Crear, por ejemplo:
`docs/FOREX_SHADOW_FIN_CREDITOS_Y_ANALISIS.md`

Debe explicar qué hacer cuando los créditos Azure estén cerca de caducar.

### 1. Congelar experimento

```bash
sudo systemctl disable --now astra-shadow.timer
```

Verificar disabled/inactive.

### 2. Snapshot y backup

- backup Oracle
- exportar/capturar resultados Shadow
- contar total signals / HOLD / BUY / SELL / evaluated / pending
- registrar ventana temporal
- registrar gaps/fallos operativos

### 3. Cortar compute Azure

Deallocate:
- RG: `astra-forex-worker-rg`
- VM: `astra-mt5-worker`

Confirmar `Stopped (Deallocated)`.

No borrar inmediatamente.

### 4. Analizar Shadow

Separar:
- EURUSD
- USDJPY
- BUY
- SELL
- reliability buckets
- períodos temporales

Medir al menos:
- accuracy
- net pips
- Profit Factor
- expectancy
- max drawdown
- avg win
- avg loss
- max consecutive losses
- number of trades
- HOLD rate
- reliability calibration
- spread/costos si están disponibles

No usar win rate aislado como criterio.

### 5. Comparar contra backtesting

Comparar misma versión/reglas si es posible:
Shadow/live OOS vs Backtest.

Buscar:
- performance degradation
- leakage
- spread impact
- regime dependence
- pair dependence
- BUY/SELL asymmetry
- reliability miscalibration

### 6. Decisión

Clasificar PASS / INCONCLUSIVE / FAIL.

Nunca activar trading real automáticamente.

---

## F. Integrar runbook de parada/desmantelamiento

Tomar `ASTRA_FOREX_SHADOW_PARADA_Y_DESMANTELAMIENTO.md` y conservarlo/integrarlo en docs como runbook canónico.

Verificar comandos y nombres actuales contra el deployment real.

Distinguir:
- pause
- resume
- stop/start bridge
- supervisor
- deallocate
- reversible teardown
- destructive teardown

Marcar comandos destructivos claramente.

---

## G. Tests finales

Antes de cerrar:
- suite completa apropiada
- tests Shadow
- RemoteMT5Provider
- persistence/outcomes
- supervisor si aplica al repo
- comprobar cero rutas de trading real
- comprobar cero training/retraining en Shadow

No fabricar una señal live si el mercado/timing no la produce.

---

## H. Entrega final

Generar:
`ASTRA_HANDOFF_FINAL_RESULTADO.md`

Incluir:
1. commit/branch final
2. archivos modificados
3. manual canónico actualizado
4. `requirements.txt`: changed o NO CHANGE con motivo
5. ubicación memoria portátil
6. ubicación runbook de parada
7. ubicación manual fin de créditos
8. persistencia Shadow: PASS/FAIL, storage, número de señales reales, duplicados, outcomes
9. estado Oracle / Azure / Tailscale / MT5 / bridge / supervisor / shadow timer
10. trading = OFF
11. retraining = FROZEN
12. tests
13. rollback
14. deuda técnica restante

No declarar rendimiento predictivo como probado hasta tener muestra Shadow suficiente.

---

## Restricciones finales

NO:
- real trading
- `order_send`
- nuevos pares
- nuevos modelos
- nuevos targets
- Optuna
- retraining automático
- scheduler histórico
- secrets en Git
- puertos públicos nuevos
- borrar Azure/Oracle durante este handoff
- alterar resultados Shadow productivos para probar outcomes
